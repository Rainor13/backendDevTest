package com.backendtest.similar_products;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimilarProductsApplicationTests {

	@Test
	void contextLoads() {
	}

}
